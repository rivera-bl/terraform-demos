import boto3
from botocore.exceptions import ClientError
from botocore.config import Config
import datetime
import fnmatch
import json
import os
import re
import logging


logger = logging.getLogger()
logging.basicConfig(
    format="[%(asctime)s] %(levelname)s [%(module)s.%(funcName)s:%(lineno)d] %(message)s", datefmt="%H:%M:%S"
)
logger.setLevel(os.getenv('log_level', logging.INFO))

# Configure boto retries
BOTO_CONFIG = Config(retries=dict(max_attempts=5))

# Define the default resource to report to Config Rules
DEFAULT_RESOURCE_TYPE = 'AWS::S3::Bucket'

CONFIG_ROLE_TIMEOUT_SECONDS = 900

# Set to True to get the lambda to assume the Role attached on the Config service (useful for cross-account).
ASSUME_ROLE_MODE = False

# Evaluation strings for Config evaluations
COMPLIANT = 'COMPLIANT'
NON_COMPLIANT = 'NON_COMPLIANT'


# This gets the client after assuming the Config service .
def get_client(service, execution_role_arn):
    if not ASSUME_ROLE_MODE:
        return boto3.client(service)
    credentials = get_assume_role_credentials(execution_role_arn)
    return boto3.client(service, aws_access_key_id=credentials['AccessKeyId'],
                        aws_secret_access_key=credentials['SecretAccessKey'],
                        aws_session_token=credentials['SessionToken'],
                        config=BOTO_CONFIG
                        )


def get_assume_role_credentials(execution_role_arn):
    sts_client = boto3.client('sts')
    try:
        assume_role_response = sts_client.assume_role(RoleArn=execution_role_arn,
                                                      RoleSessionName="configLambdaExecution",
                                                      DurationSeconds=CONFIG_ROLE_TIMEOUT_SECONDS)
        return assume_role_response['Credentials']
    except ClientError as ex:
        if 'AccessDenied' in ex.response['Error']['Code']:
            ex.response['Error']['Message'] = "AWS Config does not have permission to assume the IAM role."
        else:
            ex.response['Error']['Message'] = "InternalError"
            ex.response['Error']['Code'] = "InternalError"
        raise ex



def build_evaluation(resource_id, compliance_type, notification_creation_time,resource_type=DEFAULT_RESOURCE_TYPE, annotation=None):
    evaluation = {}
    if annotation:
        evaluation['Annotation'] = annotation
    evaluation['ComplianceResourceType'] = resource_type
    evaluation['ComplianceResourceId'] = resource_id
    evaluation['ComplianceType'] = compliance_type
    evaluation['OrderingTimestamp'] = notification_creation_time
    return evaluation


# Check the compliance of each s3 determining if lifecycle is not enable.
def evaluate_compliance(event, context):

 # Initialize our AWS clients
    config_client = get_client('config', event["executionRoleArn"])
    
    notification_creation_time = str(json.loads(event['invokingEvent'])['notificationCreationTime'])
    # List of resource evaluations to return back to AWS Config
    evaluations = []    
    s3_client = boto3.client('s3')
    bucket_list = s3_client.list_buckets()
    
    for bucket in bucket_list['Buckets']:
        print (bucket['Name'])
        try:
            #get current data life cycle configuration
            lifecycle = s3_client.get_bucket_lifecycle(Bucket=bucket['Name'])
            rules = lifecycle['Rules']
            print('get current data life cycle configuration')
            print(rules)
            compliance_result = COMPLIANT
            reason = "Lifecycle Configured"
           
            evaluation_result = build_evaluation(bucket['Name'], compliance_result,notification_creation_time,resource_type=DEFAULT_RESOURCE_TYPE, annotation=reason)
            evaluations.append(evaluation_result)

        except Exception as e:
            compliance_result = NON_COMPLIANT
            reason = "Lifecycle Rules Not configured"
            
            evaluation_result = build_evaluation(bucket['Name'], compliance_result,notification_creation_time,resource_type=DEFAULT_RESOURCE_TYPE, annotation=reason)
            evaluations.append(evaluation_result)

    # Iterate over our evaluations 100 at a time, as put_evaluations only accepts a max of 100 evals.
    evaluations_copy = evaluations[:]
    while evaluations_copy:
        config_client.put_evaluations(Evaluations=evaluations_copy[:100], ResultToken=event['resultToken'])
        del evaluations_copy[:100]