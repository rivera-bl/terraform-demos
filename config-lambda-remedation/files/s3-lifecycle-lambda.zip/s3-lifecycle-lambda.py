###############################################################################
# Lambda function
# 
# This function is trigerred by a Cloudwath event.
# It  set up a data life cycle rule to move objects to Infrecuent Access S3 Tiering after 30 days.
# The function, required roles, etc are created via a CF template
#
from __future__ import print_function

import boto3
import json
import os

s3 = boto3.client('s3')

# Gets list of buckets to be excluded
exclusions = os.environ['Exclusions'].split(',')

def lambda_handler(event, context):
   
    buckets=event['detail']['requestParameters']['evaluations']
    print(buckets)
     
    #bucketName=buckets[0]['complianceResourceId']
    #print(bucketName)
    for bucket in buckets:
        print (bucket['complianceResourceId'])
        bucketName=bucket['complianceResourceId']
        if is_exclusion(bucketName):
            try:
                #get current data life cycle configuration
                response = s3.get_bucket_lifecycle(Bucket=bucketName)
                print('get current data life cycle configuration')
                print(response)
            except Exception as e:
                print('The lifecycle configuration does not exist')
                #Setting up data life cycle configuration
                print('Setting up lifecycle configuration')
                try:
                    response = s3.put_bucket_lifecycle_configuration(
                    Bucket=bucketName,
                    LifecycleConfiguration={
                        'Rules': [
                        {
                                'ID': 'Move Objects to Intelligent Tiering after 30 days',
                                'Prefix': '',
                                'Status': 'Enabled',
                                'Transitions': [
                                {
                                'Days': 30,
                                'StorageClass': 'INTELLIGENT_TIERING'
                                },
                                ],
                                'NoncurrentVersionTransitions': [
                                    {
                                        'NoncurrentDays': 30,
                                        'StorageClass': 'STANDARD_IA'
                                    },
                                ],
                                'NoncurrentVersionExpiration': {
                                    'NoncurrentDays': 60
                                },
                                'AbortIncompleteMultipartUpload': {
                                    'DaysAfterInitiation': 2
                                }
                            },
                        ]
                    }
                    )

                    print(response)
                except Exception as e:
                    print('Error Access Denied')   

def is_exclusion(p_resourceArn):
    for exclusion in exclusions:
        if p_resourceArn.find(exclusion) > -1:
            print("Buckect in the exclusion List ")
            return False
    print("Bucket is not in the exclusion List ")
    return True